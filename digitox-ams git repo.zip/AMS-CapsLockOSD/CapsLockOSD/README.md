# AMS Caps Lock OSD — by AMS

A small Windows app that shows a clean on-screen popup that fades in and out whenever you turn **Caps Lock ON or OFF**.

![preview](assets/preview_ams_v2.png)

▶ **AMS on YouTube:** https://www.youtube.com/channel/UCW5b5zJ1MW35P1x9--ExMvg

## Install
1. Run **`Release/AMS-CapsLockOSD-Setup.exe`** (you don't need admin rights).
2. Click **Next → Install → Finish**. The app starts and the AMS YouTube channel opens once.
3. From then on it **starts automatically every time Windows starts**.

> Windows SmartScreen may say "Windows protected your PC" because the app isn't code-signed.
> Click **More info → Run anyway**.

## Use
- Press **Caps Lock**. An AMS-branded popup appears near the bottom of the screen and fades out after about 1.5 s.
- **Tray icon:** blue means ON, grey means OFF.
  - Left-click: show the popup again
  - Right-click: **Start with Windows** · **Show preview** · **AMS on YouTube** · **Exit**

## Uninstall
Go to **Settings → Apps → AMS Caps Lock OSD → Uninstall**, or use Start menu → AMS → Uninstall.
When the uninstall finishes, the AMS YouTube channel opens once.

## Files
| Path | What |
|---|---|
| `Release/AMS-CapsLockOSD-Setup.exe` | Installer |
| `Release/CapsLockOSD.exe` | The app (portable; you can run it without installing) |
| `src/Program.cs` | Source code (C#) |
| `build.bat` | Rebuilds the exe on Windows |
| `installer/installer.nsi` | Installer script (NSIS) |

© 2026 AMS
